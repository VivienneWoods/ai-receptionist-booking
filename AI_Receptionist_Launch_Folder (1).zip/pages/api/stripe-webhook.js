// Node.js handler for Stripe webhooks
