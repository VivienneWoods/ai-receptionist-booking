// Admin dashboard entry point
