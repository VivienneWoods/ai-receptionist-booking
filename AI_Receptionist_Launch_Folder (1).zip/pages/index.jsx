// Main booking page entry point
