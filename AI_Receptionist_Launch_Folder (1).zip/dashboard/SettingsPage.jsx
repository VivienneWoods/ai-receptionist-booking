// Settings page for language, currency, hours
