// Admin dashboard home with stats
