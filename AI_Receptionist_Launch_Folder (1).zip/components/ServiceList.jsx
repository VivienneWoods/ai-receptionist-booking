// React component for listing services
