// React component for uploading image
