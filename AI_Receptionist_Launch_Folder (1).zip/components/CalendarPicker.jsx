// React component for date/time picker
