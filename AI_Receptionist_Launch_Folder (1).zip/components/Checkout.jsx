// React component for Stripe checkout
