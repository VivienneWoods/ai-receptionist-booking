// React component for Booking Form
