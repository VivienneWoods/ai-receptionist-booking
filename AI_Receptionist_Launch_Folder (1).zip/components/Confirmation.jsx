// React component for final confirmation
