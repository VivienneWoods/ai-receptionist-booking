// Next.js configuration
