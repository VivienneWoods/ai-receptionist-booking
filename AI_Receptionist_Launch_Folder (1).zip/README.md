# AI Receptionist App

This archive includes all files needed to run and customize your booking system with multilingual support, Stripe payments, and Firebase backend.
